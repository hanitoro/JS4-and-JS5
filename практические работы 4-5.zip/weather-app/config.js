// Добавьте свой ключ OpenWeatherMap.
window.WEATHER_CONFIG = { apiKey: "" };
