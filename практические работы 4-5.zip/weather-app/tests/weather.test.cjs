const { test } = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const source = fs.readFileSync(path.join(__dirname, "..", "main.js"), "utf8");

// Минимальные DOM-узлы; реальные разметка и CSS проверяются отдельно в браузере.
function element() {
  return {
    value: "", textContent: "", innerHTML: "", hidden: false, attrs: {}, handlers: {}, children: {},
    classList: { values: new Set(), toggle(name, value) { value ? this.values.add(name) : this.values.delete(name); } },
    setAttribute(name, value) { this.attrs[name] = value; },
    addEventListener(name, handler) { this.handlers[name] = handler; },
    querySelector(selector) { return this.children[selector] ||= element(); },
    setCustomValidity(message) { this.validity = message; },
    reportValidity() { this.reported = true; },
  };
}

async function setup({ key = "test-key", savedCity, fetchImpl, storageThrows = false } = {}) {
  const nodes = Object.fromEntries([".app", ".search-box", ".search-bar", ".container", ".demo-notice"].map(name => [name, element()]));
  const saved = new Map(savedCity ? [["city", savedCity]] : []);
  const calls = [];
  const context = vm.createContext({
    window: { WEATHER_CONFIG: { apiKey: key }, location: { search: "" } },
    document: { querySelector: selector => nodes[selector] },
    localStorage: {
      getItem(name) { if (storageThrows) throw new Error("blocked"); return saved.get(name) || null; },
      setItem(name, value) { if (storageThrows) throw new Error("blocked"); saved.set(name, value); },
    },
    fetch: async (...args) => { calls.push(args); return fetchImpl ? fetchImpl(...args) : response(); },
    URLSearchParams, AbortController, TypeError, setTimeout, clearTimeout, console,
  });
  vm.runInContext(source, context);
  // Дожидаемся начальной загрузки, в том числе цепочки чтения JSON.
  await new Promise(resolve => setImmediate(resolve));
  return { nodes, saved, calls, context, run: code => vm.runInContext(code, context) };
}

function response(temp = -6, name = "Екатеринбург") {
  return { ok: true, json: async () => ({ name, main: { temp }, sys: { country: "RU" }, weather: [{ description: "небольшой снег" }] }) };
}

test("запрашивает начальный город в °C и на русском, отображает ответ и сохраняет город", async () => {
  const app = await setup();
  const url = new URL(app.calls[0][0]);
  assert.equal(url.searchParams.get("q"), "Екатеринбург");
  assert.equal(url.searchParams.get("units"), "metric");
  assert.equal(url.searchParams.get("lang"), "ru");
  assert.equal(app.nodes[".container"].querySelector(".temp").textContent, "-6 °C");
  assert.equal(app.nodes[".container"].querySelector(".city").textContent, "Екатеринбург, RU");
  assert.equal(app.saved.get("city"), "Екатеринбург");
  assert.equal(app.nodes[".container"].attrs["aria-busy"], "false");
});

test("восстанавливает город из localStorage", async () => {
  const app = await setup({ savedCity: "Москва" });
  assert.equal(new URL(app.calls[0][0]).searchParams.get("q"), "Москва");
});

test("граница тёплого фона строго выше 15 °C", async () => {
  const app = await setup({ fetchImpl: async () => response(15) });
  assert.equal(app.nodes[".app"].classList.values.has("warm"), false);
  app.context.fetch = async () => response(15.1);
  await app.run('fetchData("Москва")');
  assert.equal(app.nodes[".app"].classList.values.has("warm"), true);
});

test("отправка формы убирает пробелы и очищает поле после успеха", async () => {
  const app = await setup();
  const input = app.nodes[".search-bar"];
  input.value = "  London,GB  ";
  await app.nodes[".search-box"].handlers.submit({ preventDefault() {} });
  assert.equal(new URL(app.calls.at(-1)[0]).searchParams.get("q"), "London,GB");
  assert.equal(input.value, "");
});

test("пустой ввод не вызывает API", async () => {
  const app = await setup();
  const before = app.calls.length;
  app.nodes[".search-bar"].value = "   ";
  await app.nodes[".search-box"].handlers.submit({ preventDefault() {} });
  assert.equal(app.calls.length, before);
  assert.equal(app.nodes[".search-bar"].reported, true);
});

for (const [status, text] of [[401, "API-ключ"], [404, "Город не найден"], [429, "лимит"], [503, "недоступен"]]) {
  test(`ошибка HTTP ${status} объясняется и не заменяет сохранённый город`, async () => {
    const app = await setup();
    app.context.fetch = async () => ({ ok: false, status });
    await app.run('fetchData("несуществующий город")');
    assert.ok(app.nodes[".container"].querySelector(".error-text").textContent.includes(text));
    assert.equal(app.saved.get("city"), "Екатеринбург");
  });
}

test("сетевая ошибка отображается и снимает состояние загрузки", async () => {
  const app = await setup({ fetchImpl: async () => { throw new TypeError("network"); } });
  assert.match(app.nodes[".container"].querySelector(".error-text").textContent, /соединения/);
  assert.equal(app.nodes[".container"].attrs["aria-busy"], "false");
});

test("старый ответ не перезаписывает более новый результат", async () => {
  const app = await setup();
  let finishOld;
  app.context.fetch = () => new Promise(resolve => { finishOld = resolve; });
  const oldRequest = app.run('fetchData("Москва")');
  app.context.fetch = async () => response(20, "Лондон");
  await app.run('fetchData("Лондон")');
  finishOld(response(2, "Москва"));
  await oldRequest;
  assert.equal(app.nodes[".container"].querySelector(".city").textContent, "Лондон, RU");
  assert.equal(app.saved.get("city"), "Лондон");
});

test("без ключа нет запросов и есть понятная инструкция", async () => {
  const app = await setup({ key: "" });
  assert.equal(app.calls.length, 0);
  assert.match(app.nodes[".container"].innerHTML, /config\.js/);
});

test("блокировка хранилища не мешает загрузке", async () => {
  const app = await setup({ storageThrows: true });
  assert.equal(app.nodes[".container"].querySelector(".temp").textContent, "-6 °C");
});

test("дата корректно форматируется на границе года", async () => {
  const app = await setup();
  assert.equal(app.run("dateBuilder(new Date(2026, 0, 1))"), "Четверг, 1 января 2026");
});
