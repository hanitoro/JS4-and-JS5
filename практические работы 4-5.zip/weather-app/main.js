"use strict";

// Как в уроке: запрос -> store -> renderComponent -> getContent.
const api = {
  base: "https://api.openweathermap.org/data/2.5/weather",
  key: window.WEATHER_CONFIG?.apiKey?.trim() || "",
};

const app = document.querySelector(".app");
const form = document.querySelector(".search-box");
const input = document.querySelector(".search-bar");
const container = document.querySelector(".container");
const demoMode = new URLSearchParams(window.location.search).get("demo") === "1";
let store = null;
let activeRequest = null;

function readCity() {
  try {
    return localStorage.getItem("city")?.trim() || "Екатеринбург";
  } catch {
    // Запрет localStorage не должен мешать просмотру погоды.
    return "Екатеринбург";
  }
}

function saveCity(city) {
  try {
    localStorage.setItem("city", city);
  } catch {
    // В приватном режиме сохранение может быть недоступно.
  }
}

function dateBuilder(date) {
  const days = ["Воскресенье", "Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота"];
  const months = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря"];
  return `${days[date.getDay()]}, ${date.getDate()} ${months[date.getMonth()]} ${date.getFullYear()}`;
}

function getContent() {
  // Шаблон содержит только разметку. Данные добавляем через textContent.
  return `
    <div class="location-box">
      <h2 class="city"></h2>
      <p class="date"></p>
    </div>
    <div class="weather-box">
      <p class="temperature-label">Сейчас</p>
      <div class="temp"></div>
      <p class="weather"></p>
    </div>`;
}

function renderComponent() {
  const { name, country, temp, weather } = store;
  container.innerHTML = getContent();
  container.querySelector(".city").textContent = country ? `${name}, ${country}` : name;
  container.querySelector(".date").textContent = dateBuilder(new Date());
  container.querySelector(".temp").textContent = `${Math.round(temp)} °C`;
  container.querySelector(".weather").textContent = weather;
  app.classList.toggle("warm", temp > 15);
}

function getLoader() {
  container.setAttribute("aria-busy", "true");
  container.innerHTML = '<div class="loading"><span class="loader" aria-hidden="true"></span><p>Узнаём погоду…</p></div>';
}

function showError(message) {
  container.innerHTML = '<div class="message"><h2>Не удалось узнать погоду</h2><p class="error-text"></p><p class="hint">Проверьте данные и попробуйте ещё раз.</p></div>';
  container.querySelector(".error-text").textContent = message;
}

function showSetup() {
  container.innerHTML = `
    <div class="message">
      <h2>Почти готово</h2>
      <p>Для загрузки погоды добавьте свой ключ OpenWeatherMap в файл config.js и обновите страницу.</p>
      <a class="demo-link" href="?demo=1">Посмотреть демонстрацию</a>
    </div>`;
}

// Только для проверки интерфейса без ключа. Здесь нет актуальных погодных данных.
const demoCities = [
  { names: ["екатеринбург", "yekaterinburg", "ekaterinburg"], name: "Екатеринбург", country: "RU", temp: -6, weather: "небольшой снег" },
  { names: ["москва", "moscow"], name: "Москва", country: "RU", temp: 8, weather: "облачно с прояснениями" },
  { names: ["лондон", "london"], name: "Лондон", country: "GB", temp: 18, weather: "ясно" },
];

function getDemoWeather(city) {
  const result = demoCities.find(item => item.names.includes(city.toLocaleLowerCase("ru")));
  if (!result) {
    throw new Error("В демонстрации доступны Екатеринбург, Москва и Лондон. Для других городов подключите API-ключ.");
  }
  return result;
}

async function fetchData(city) {
  // Отмена предыдущего запроса защищает от устаревших ответов при быстром поиске.
  activeRequest?.abort();
  if (!demoMode && !api.key) {
    showSetup();
    return false;
  }

  const controller = new AbortController();
  activeRequest = controller;
  let timedOut = false;
  const timeout = setTimeout(() => {
    timedOut = true;
    controller.abort();
  }, 12000);
  getLoader();

  try {
    let nextStore;
    if (demoMode) {
      // Даём браузеру отобразить загрузку в демонстрации.
      await new Promise(resolve => setTimeout(resolve, 350));
      nextStore = getDemoWeather(city);
    } else {
      const params = new URLSearchParams({ q: city, appid: api.key, units: "metric", lang: "ru" });
      const response = await fetch(`${api.base}?${params}`, { signal: controller.signal });
      if (!response.ok) {
        const messages = {
          401: "API-ключ не принят. Проверьте ключ OpenWeatherMap и его активацию.",
          404: "Город не найден. Уточните название; при необходимости добавьте код страны: London,GB.",
          429: "Превышен лимит запросов к погодному сервису. Попробуйте позже.",
        };
        throw new Error(messages[response.status] || "Погодный сервис временно недоступен.");
      }

      const data = await response.json();
      // Деструктуризация полей ответа, как в лекции.
      const { name, main: { temp } = {}, sys: { country } = {}, weather } = data;
      if (typeof name !== "string" || !Number.isFinite(temp) || !weather?.[0]?.description) {
        throw new Error("Погодный сервис вернул неполные данные.");
      }
      nextStore = { name, country, temp, weather: weather[0].description };
    }

    if (controller.signal.aborted) {
      if (timedOut) throw new Error("Сервис не ответил вовремя. Попробуйте ещё раз.");
      return false;
    }
    store = nextStore;
    renderComponent();
    // Сохраняем только город, по которому получен успешный ответ.
    if (!demoMode) saveCity(city);
    return true;
  } catch (error) {
    if (controller.signal.aborted && !timedOut) return false;
    const message = timedOut
      ? "Сервис не ответил вовремя. Попробуйте ещё раз."
      : error instanceof TypeError
        ? "Нет соединения с погодным сервисом. Проверьте подключение к интернету."
        : error.message;
    showError(message);
    return false;
  } finally {
    clearTimeout(timeout);
    if (activeRequest === controller) {
      container.setAttribute("aria-busy", "false");
      activeRequest = null;
    }
  }
}

// Submit работает и по Enter, и по кнопке, в том числе на телефоне.
form.addEventListener("submit", async event => {
  event.preventDefault();
  const city = input.value.trim();
  if (!city) {
    input.setCustomValidity("Введите название города.");
    input.reportValidity();
    return;
  }
  input.setCustomValidity("");
  if (await fetchData(city)) input.value = "";
});

input.addEventListener("input", () => input.setCustomValidity(""));
document.querySelector(".demo-notice").hidden = !demoMode;
fetchData(demoMode ? "Екатеринбург" : readCity());
