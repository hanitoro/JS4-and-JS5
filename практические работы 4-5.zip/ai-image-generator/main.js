"use strict";

const examplePrompts = [
  "Небольшая обсерватория на вершине горы, звёздное небо, тёплый свет в окнах, тихая зимняя ночь",
  "Рыжий кот-космонавт исследует оранжерею на Марсе, большие листья, мягкий солнечный свет",
  "Уютный книжный магазин в дождливом городе, мокрая мостовая, отражения фонарей и золотистые витрины",
  "Парящий остров с водопадом и старинным замком среди облаков, утренний туман, сказочная атмосфера",
  "Маленький робот выращивает сад на крыше небоскрёба, далёкий город будущего, закат",
  "Лесной домик у озера, сосны отражаются в воде, первые лучи солнца и лёгкая дымка",
];

const promptInput = document.querySelector(".prompt-input");
const promptBtn = document.querySelector(".prompt-btn");
const themeToggle = document.querySelector(".theme-toggle");
const form = document.querySelector(".prompt-form");
const generateBtn = document.querySelector(".generate-btn");
const generateLabel = document.querySelector(".generate-label");
const cancelBtn = document.querySelector(".cancel-btn");
const imageCard = document.querySelector(".image-card");
const resultImg = document.querySelector(".result-img");
const downloadLink = document.querySelector(".download-link");
const errorMessage = document.querySelector(".error-message");
const caption = document.querySelector(".result-caption");
const characterCount = document.querySelector(".character-count");
const config = window.IMAGE_CONFIG || {};
const demoMode = new URLSearchParams(location.search).get("demo") === "1";
let currentImageUrl = null;
let controller = null;
let isGenerating = false;

function setClassToThemeIcon(isDarkTheme) {
  themeToggle.setAttribute("aria-pressed", String(isDarkTheme));
  themeToggle.setAttribute("aria-label", isDarkTheme ? "Включить светлую тему" : "Включить тёмную тему");
}

function startTheme() {
  let savedTheme = null;
  try { savedTheme = localStorage.getItem("theme"); } catch { /* Хранилище может быть недоступно. */ }
  const isDarkTheme = savedTheme === "dark";
  document.body.classList.toggle("dark-theme", isDarkTheme);
  setClassToThemeIcon(isDarkTheme);
}

themeToggle.addEventListener("click", () => {
  const isDarkTheme = document.body.classList.toggle("dark-theme");
  try { localStorage.setItem("theme", isDarkTheme ? "dark" : "light"); } catch { /* Смена темы работает и без сохранения. */ }
  setClassToThemeIcon(isDarkTheme);
});

function updateCharacterCount() {
  characterCount.textContent = `${promptInput.value.length} / 1200`;
  promptInput.setCustomValidity("");
}

promptBtn.addEventListener("click", () => {
  const prompt = examplePrompts[Math.floor(Math.random() * examplePrompts.length)];
  promptInput.value = prompt;
  updateCharacterCount();
  promptInput.focus();
});
promptInput.addEventListener("input", updateCharacterCount);

function startLoading() {
  isGenerating = true;
  imageCard.classList.add("loading");
  imageCard.setAttribute("aria-busy", "true");
  generateBtn.disabled = true;
  generateLabel.textContent = "Создаём…";
  cancelBtn.hidden = false;
  downloadLink.hidden = true;
  errorMessage.hidden = true;
  caption.textContent = "";
}

function endLoading() {
  isGenerating = false;
  imageCard.classList.remove("loading");
  imageCard.setAttribute("aria-busy", "false");
  generateBtn.disabled = false;
  generateLabel.textContent = "Создать изображение";
  cancelBtn.hidden = true;
  downloadLink.hidden = !currentImageUrl;
}

async function handleGenerateImage(objectFormData) {
  if (isGenerating) return;
  const prompt = ImageCore.buildPrompt(objectFormData);
  const requestController = new AbortController();
  controller = requestController;
  startLoading();
  let pendingUrl = null;

  try {
    if (demoMode) await new Promise(resolve => setTimeout(resolve, 500));
    if (requestController.signal.aborted) return;
    const blob = await ImageCore.requestImage(window.axios, config, prompt, {
      signal: requestController.signal,
      demo: demoMode,
    });
    if (requestController.signal.aborted) return;
    pendingUrl = URL.createObjectURL(blob);
    // Заканчиваем загрузку только тогда, когда браузер действительно прочитал картинку.
    const preview = new Image();
    preview.src = pendingUrl;
    try { await preview.decode(); } catch { throw new Error("IMAGE_DECODE"); }
    if (requestController.signal.aborted) return;

    const previousUrl = currentImageUrl;
    resultImg.src = pendingUrl;
    resultImg.alt = demoMode ? "Демонстрационная иллюстрация: обсерватория в горах" : objectFormData.prompt;
    downloadLink.href = pendingUrl;
    downloadLink.download = `ai-image.${ImageCore.fileExtension(blob.type)}`;
    currentImageUrl = pendingUrl;
    pendingUrl = null;
    imageCard.classList.add("has-image");
    caption.textContent = demoMode
      ? "Демонстрационная иллюстрация — это готовый SVG, а не результат генерации по вашему описанию."
      : `Готово: ${objectFormData.prompt}`;
    if (previousUrl) URL.revokeObjectURL(previousUrl);
  } catch (error) {
    if (!requestController.signal.aborted && error.code !== "ERR_CANCELED") {
      errorMessage.textContent = ImageCore.getErrorMessage(error, { demo: demoMode });
      errorMessage.hidden = false;
    }
  } finally {
    if (pendingUrl) URL.revokeObjectURL(pendingUrl);
    if (requestController.signal.aborted) caption.textContent = "Генерация отменена.";
    controller = null;
    endLoading();
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();
  if (isGenerating) return;
  if (!promptInput.value.trim()) {
    promptInput.setCustomValidity("Опишите изображение: одних пробелов недостаточно.");
    promptInput.reportValidity();
    return;
  }
  if (!form.reportValidity()) return;
  const formData = new FormData(event.currentTarget);
  const objectFormData = Object.fromEntries(formData.entries());
  objectFormData.prompt = objectFormData.prompt.trim();
  handleGenerateImage(objectFormData);
});

cancelBtn.addEventListener("click", () => controller?.abort());
window.addEventListener("pagehide", () => {
  controller?.abort();
  if (currentImageUrl) {
    URL.revokeObjectURL(currentImageUrl);
    currentImageUrl = null;
    resultImg.removeAttribute("src");
    imageCard.classList.remove("has-image");
    downloadLink.hidden = true;
  }
});

startTheme();
document.querySelector(".demo-notice").hidden = !demoMode;
document.querySelector(".setup-notice").hidden = demoMode || Boolean(config.apiKey?.trim());
