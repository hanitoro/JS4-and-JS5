const { test } = require("node:test");
const assert = require("node:assert/strict");
const { buildPrompt, requestImage, getErrorMessage, fileExtension } = require("../core.js");

const config = { apiKey: " test-key ", model: "black-forest-labs/flux.1-schnell", width: 1024, height: 1024 };
const image = new Blob(["test-image-bytes"], { type: "image/png" });

test("все поля формы входят в единый промпт, включая добавленное поле", () => {
  const prompt = buildPrompt({ prompt: "  Рыжий кот  ", colorization: "full color", imageStyle: "pixel art", contrast: "high", lighting: "sunset" });
  assert.equal(prompt, "prompt: Рыжий кот. colorization: full color. imageStyle: pixel art. contrast: high. lighting: sunset");
});

test("промпт кодируется, токен передаётся заголовком, ответ запрашивается как Blob", async () => {
  let actual;
  const client = { get: async (url, options) => { actual = { url, options }; return { data: image }; } };
  const controller = new AbortController();
  const prompt = "Кот & звёзды / ночь? #1";
  const result = await requestImage(client, config, prompt, { signal: controller.signal });
  assert.equal(result, image);
  assert.equal(actual.url, `https://gen.pollinations.ai/image/${encodeURIComponent(prompt)}`);
  assert.equal(actual.url.includes("test-key"), false);
  assert.equal(actual.options.headers.Authorization, "Bearer test-key");
  assert.equal(actual.options.responseType, "blob");
  assert.deepEqual(actual.options.params, { model: config.model, width: 1024, height: 1024 });
  assert.equal(actual.options.signal, controller.signal);
  assert.equal(actual.options.timeout, 90000);
});

test("без ключа настоящий запрос не отправляется", async () => {
  let calls = 0;
  await assert.rejects(requestImage({ get: async () => { calls++; } }, { apiKey: " " }, "cat"), /MISSING_KEY/);
  assert.equal(calls, 0);
});

test("отсутствующий Axios объясняется отдельно", async () => {
  await assert.rejects(requestImage(undefined, config, "cat"), /MISSING_AXIOS/);
  assert.match(getErrorMessage(new Error("MISSING_AXIOS")), /Axios/);
});

test("демо работает без Axios и ключа, не выполняя запросов", async () => {
  const result = await requestImage(undefined, {}, "private prompt", { demo: true, demoSvg: '<svg xmlns="http://www.w3.org/2000/svg"/>' });
  assert.equal(result.type, "image/svg+xml");
  assert.equal(await result.text(), '<svg xmlns="http://www.w3.org/2000/svg"/>');
});

test("демо не обращается к переданному HTTP-клиенту", async () => {
  let calls = 0;
  const client = { get: async () => { calls++; throw new Error("Network blocked"); } };
  await requestImage(client, config, "private prompt", { demo: true, demoSvg: "<svg/>" });
  assert.equal(calls, 0);
});

test("отсутствующая демо-иллюстрация объясняется как локальная ошибка", async () => {
  await assert.rejects(requestImage(undefined, {}, "cat", { demo: true, demoSvg: "" }), /MISSING_DEMO/);
  assert.match(getErrorMessage(new Error("MISSING_DEMO")), /demo-image\.js/);
});

test("ошибка в демо не предлагает проверять подключение к Pollinations", () => {
  const message = getErrorMessage({ code: "ERR_NETWORK" }, { demo: true });
  assert.match(message, /встроенную демонстрационную/);
  assert.doesNotMatch(message, /Проверьте интернет/);
});

test("отмена демо не создаёт изображение и не вызывает HTTP-клиент", async () => {
  const controller = new AbortController();
  controller.abort();
  await assert.rejects(requestImage(undefined, {}, "cat", { demo: true, demoSvg: "<svg/>", signal: controller.signal }), error => error.code === "ERR_CANCELED");
});

for (const [label, data] of [
  ["пустое изображение", new Blob([], { type: "image/png" })],
  ["HTML вместо картинки", new Blob(["<html>error</html>"], { type: "text/html" })],
  ["ошибку JSON со статусом 200", new Blob(['{"error":"no credits"}'], { type: "application/json" })],
  ["обычный объект вместо Blob", { url: "https://example.test/image.png" }],
]) {
  test(`не отображает ${label}`, async () => {
    await assert.rejects(requestImage({ get: async () => ({ data }) }, config, "cat"), /INVALID_IMAGE/);
  });
}

test("ошибка запроса сохраняется для обработчика, без повторной генерации", async () => {
  const error = { response: { status: 429 } };
  let calls = 0;
  await assert.rejects(requestImage({ get: async () => { calls++; throw error; } }, config, "cat"), value => value === error);
  assert.equal(calls, 1);
});

test("авторизация, баланс, лимит и сбой сервиса имеют отдельные сообщения", () => {
  for (const [status, expected] of [[401, /ключ/], [402, /баланс/], [403, /доступа/], [429, /много запросов/], [503, /временно недоступен/]]) {
    assert.match(getErrorMessage({ response: { status } }), expected);
  }
});

test("таймаут и сетевая ошибка не остаются без пояснения", () => {
  assert.match(getErrorMessage({ code: "ECONNABORTED" }), /90 секунд/);
  assert.match(getErrorMessage({ code: "ETIMEDOUT" }), /90 секунд/);
  assert.match(getErrorMessage({ code: "ERR_NETWORK" }), /подключиться/);
});

test("неизвестная ошибка не раскрывает техническое сообщение сервера или ключ", () => {
  const message = getErrorMessage(new Error("private-token-in-technical-error"));
  assert.equal(message.includes("private-token"), false);
  assert.match(message, /Не удалось/);
});

test("расширение скачивания соответствует типу изображения", () => {
  assert.equal(fileExtension("image/jpeg"), "jpg");
  assert.equal(fileExtension("image/svg+xml;charset=utf-8"), "svg");
  assert.equal(fileExtension("image/webp"), "webp");
});
