const { test } = require("node:test");
const assert = require("node:assert/strict");
const { readFileSync } = require("node:fs");
const { join } = require("node:path");
const vm = require("node:vm");

test("полная отправка формы в демо без сервера и Axios показывает встроенную картинку", async () => {
  function element() {
    const classes = new Set();
    return {
      value: "", hidden: false, textContent: "", attrs: {}, handlers: {},
      classList: {
        add(name) { classes.add(name); },
        remove(name) { classes.delete(name); },
        contains(name) { return classes.has(name); },
        toggle(name, force) { const next = force ?? !classes.has(name); next ? classes.add(name) : classes.delete(name); return next; },
      },
      addEventListener(name, handler) { this.handlers[name] = handler; },
      setAttribute(name, value) { this.attrs[name] = value; },
      removeAttribute(name) { delete this.attrs[name]; },
      setCustomValidity() {}, reportValidity() { return true; }, focus() {},
    };
  }
  const nodes = new Map();
  const getNode = selector => {
    if (!nodes.has(selector)) nodes.set(selector, element());
    return nodes.get(selector);
  };
  const windowEvents = {};
  const sandbox = {
    Blob, URL, URLSearchParams, AbortController,
    location: { protocol: "file:", search: "?demo=1" },
    document: { body: element(), querySelector: getNode },
    localStorage: { getItem() { return null; }, setItem() {} },
    IMAGE_CONFIG: { apiKey: "" },
    Image: class { async decode() {} },
    FormData: class { constructor(form) { this.values = form.values; } entries() { return Object.entries(this.values); } },
    setTimeout(callback) { queueMicrotask(callback); return 0; },
    addEventListener(name, handler) { windowEvents[name] = handler; },
  };
  sandbox.window = sandbox;
  const context = vm.createContext(sandbox);
  for (const file of ["demo-image.js", "core.js", "main.js"]) {
    vm.runInContext(readFileSync(join(__dirname, "..", file), "utf8"), context, { filename: file });
  }
  const form = getNode(".prompt-form");
  form.values = { prompt: "Обсерватория", colorization: "full color", imageStyle: "pixel art", contrast: "medium" };
  getNode(".prompt-input").value = form.values.prompt;
  form.handlers.submit({ preventDefault() {}, currentTarget: form });
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(getNode(".image-card").classList.contains("has-image"), true);
  assert.equal(getNode(".image-card").classList.contains("loading"), false);
  assert.equal(getNode(".image-card").attrs["aria-busy"], "false");
  assert.match(getNode(".result-img").src, /^blob:/);
  assert.equal(getNode(".download-link").download, "ai-image.svg");
  assert.equal(getNode(".error-message").hidden, true);
  assert.equal(getNode(".generate-btn").disabled, false);
  assert.equal(getNode(".demo-notice").hidden, false);
  assert.match(getNode(".result-caption").textContent, /готовый SVG/);
  windowEvents.pagehide();
});
