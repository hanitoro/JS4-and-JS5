@echo off
cd /d "%~dp0"
echo Open http://127.0.0.1:8001 in your browser.
echo Demo: http://127.0.0.1:8001/demo.html
echo You can also open demo.html directly without this server.
echo Press Ctrl+C to stop the server.
python -m http.server 8001 --bind 127.0.0.1
pause
