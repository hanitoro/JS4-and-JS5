// Добавьте свой ключ Pollinations.
window.IMAGE_CONFIG = { apiKey: "", model: "black-forest-labs/flux.1-schnell", width: 1024, height: 1024 };
