"use strict";

// Функции запросов вынесены отдельно, чтобы проверять их без настоящей генерации.
(function (root) {
  function buildPrompt(formObject) {
    // FormData -> Object.fromEntries -> Object.entries -> map -> join, как в уроке.
    return Object.entries(formObject)
      .map(([key, value]) => `${key}: ${String(value).trim()}`)
      .join(". ");
  }

  async function requestImage(client, config, prompt, { signal, demo = false, demoSvg = root.IMAGE_DEMO_SVG } = {}) {
    let blob;
    if (demo) {
      // Встроенный SVG работает и при открытии через file://, без HTTP-запросов.
      if (signal?.aborted) {
        const error = new Error("Генерация отменена");
        error.code = "ERR_CANCELED";
        throw error;
      }
      if (typeof demoSvg !== "string" || !demoSvg.trim()) throw new Error("MISSING_DEMO");
      blob = new Blob([demoSvg], { type: "image/svg+xml" });
    } else {
      if (!client?.get) throw new Error("MISSING_AXIOS");
      const apiKey = config.apiKey?.trim();
      if (!apiKey) throw new Error("MISSING_KEY");
      const response = await client.get(`https://gen.pollinations.ai/image/${encodeURIComponent(prompt)}`, {
        headers: { Authorization: `Bearer ${apiKey}` },
        params: { model: config.model, width: config.width, height: config.height },
        responseType: "blob",
        timeout: 90000,
        signal,
      });
      blob = response.data;
    }
    if (!(blob instanceof Blob) || !blob.size || !/^image\/(png|jpeg|webp|gif|avif|svg\+xml)(;|$)/i.test(blob.type)) {
      throw new Error("INVALID_IMAGE");
    }
    return blob;
  }

  function getErrorMessage(error, { demo = false } = {}) {
    if (error.message === "MISSING_DEMO") return "Не найдена встроенная демонстрационная иллюстрация. Проверьте, что файл demo-image.js находится рядом с index.html, или распакуйте обновлённый проект целиком.";
    if (demo) return "Не удалось открыть встроенную демонстрационную иллюстрацию. Распакуйте обновлённый проект целиком и откройте demo.html. Подключение к Pollinations для демо не требуется.";
    if (error.message === "MISSING_KEY") return "Добавьте свой API-ключ Pollinations в config.js и обновите страницу. Без ключа можно открыть демо по ссылке выше.";
    if (error.message === "MISSING_AXIOS") return "Библиотека Axios не загрузилась. Проверьте, что папка vendor находится рядом с index.html.";
    if (["INVALID_IMAGE", "IMAGE_DECODE"].includes(error.message)) return "Сервис вернул файл, который не удалось открыть как изображение. Попробуйте ещё раз.";
    if (["ECONNABORTED", "ETIMEDOUT"].includes(error.code)) return "Сервис не ответил за 90 секунд. Попробуйте ещё раз или упростите описание.";
    const messages = {
      400: "Сервис не принял параметры изображения. Проверьте описание и модель в config.js.",
      401: "API-ключ не принят. Проверьте свой ключ Pollinations.",
      402: "Сервис сообщает о недостаточном балансе для генерации. Проверьте аккаунт Pollinations.",
      403: "У ключа нет доступа к выбранной модели или запрос отклонён сервисом.",
      404: "Выбранная модель или адрес запроса недоступны. Проверьте config.js и документацию сервиса.",
      429: "Слишком много запросов. Подождите немного и попробуйте ещё раз.",
    };
    if (messages[error.response?.status]) return messages[error.response.status];
    if (error.response?.status >= 500) return "Сервис генерации временно недоступен. Попробуйте позже.";
    if (error.code === "ERR_NETWORK") return "Не удалось подключиться к Pollinations. Проверьте интернет и доступность сервиса.";
    return "Не удалось создать изображение. Проверьте подключение и попробуйте ещё раз.";
  }

  function fileExtension(type) {
    return ({ "image/jpeg": "jpg", "image/png": "png", "image/webp": "webp", "image/gif": "gif", "image/avif": "avif", "image/svg+xml": "svg" })[type.split(";")[0].toLowerCase()] || "png";
  }

  const api = { buildPrompt, requestImage, getErrorMessage, fileExtension };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  else root.ImageCore = api;
})(globalThis);
